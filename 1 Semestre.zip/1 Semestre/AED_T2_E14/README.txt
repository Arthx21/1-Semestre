O E13 , E14 , E15 estão atrasados

Apenas o E16 sendo estregue em data correta.